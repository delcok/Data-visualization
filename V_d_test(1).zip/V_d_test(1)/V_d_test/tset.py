# !/usr/bin/python
# -*-coding:utf-8_*_
# 作者      :tanxiaolong
# 创建时间  :2020/2/17 5:18 下午
# 文件      :tset.py
# IDE       :PyCharm
import multiprocessing
# cpu_num的个数
cpu_num = multiprocessing.cpu_count()
import psutil
print(psutil.cpu_times())
# print(psutil.cpu_count())
# print(multiprocessing.cpu_count())