import psutil as ps
import re
from django.core.mail import send_mail
import time
class Cpu:
    def __init__(self):
        self._cpu_count = ps.cpu_count()
        self._cpu_count_logical = ps.cpu_count(logical=False)
        self._cpu_percent = ps.cpu_percent()
        self._pids = ps.pids()
    @property
    def get_freq(self):
        #  频率 Mhz
        return ps.cpu_freq()

class CpuData(Cpu):
    def __init__(self):
        super(CpuData, self).__init__()

    def get_cpu_number(self):
        #cpu逻辑核心， 物理核心, 可用cpu
        return self._cpu_count, self._cpu_count_logical,len(ps.Process().cpu_affinity())

    @property
    def get_data(self):
        return {"cpun":self._cpu_count, "cpuu":self._cpu_count_logical, "pidl":len(self._pids)}

    @property
    def get_percent(self):
        if hasattr(self, 'percent_datas'):
            now_percent = ps.cpu_percent()
            self.percent_datas.append(now_percent)
            if len(self.percent_datas) > 60:
                del self.percent_datas[0]
            return self.percent_datas

        self.percent_datas = []
        self.percent_datas.append(self._cpu_percent)
        return self.percent_datas

    @property
    def get_now_percent(self):
        return ps.cpu_percent()

    @property
    def get_freq(self):
        # Linux 动态 其他固定  单位 Ghz
        data = super().get_freq
        return round(data.current / 1000, 2)

    def get_pid_number(self):
        return len(ps.pids())

class Memory:
    def __init__(self):
        pass

    @property
    def _physical_memory(self):
        return ps.virtual_memory()

    @property
    def get_total(self):
        return round(self._physical_memory.total/(1024**3),2)

    @property
    def get_used_free_data(self):
        data = self._physical_memory
        return round(data.used/(1024**3),2), round(data.free/(1024**3),2)


    @property
    def get_swap_info(self):
        return ps.swap_memory()

    @property
    def get_swap_total(self):
        return round(self.get_swap_info.total/(1024**3), 2)
    @property
    def get_swap_data(self):
        data = self.get_swap_info
        return round(data.used/(1024**3), 2), round(data.free/(1024**3), 2)
    @property
    def get_percent(self):
        # 使用率
        return self._physical_memory.percent

    def __str__(self):
        text = "内存大小:{}G 内存使用率:% {}"

        text = text.format(self.get_total, self.get_percent)
        return text

class IoInfo:
    def __init__(self):
        pass

    @property
    def _disk_par(self):
        # 磁盘信息
        if hasattr(self, "disk_partitions"):
            return self.disk_partitions
        self.disk_partitions = ps.disk_partitions(all=True)

    @property
    def disk_number(self):
        return len(self._disk_par)

    @property
    def _disk_usage(self):
        # 磁盘使用信息
        return ps.disk_usage('/')

    @property
    def get_total(self):
        # 总大小
        total = sum(disk.total for disk in self._all_disk()[0])
        return round(total/(1024**3),1)

    @property
    def disk_used_free_data(self):
        data =  self._all_disk()[0]
        return round(sum(disk.used for disk in data)/(1024**3),2), round(sum(disk.free for disk in data)/(1024**3), 2)

    @property
    def disk_percent(self):
        data = self._all_disk()[0]
        return sum(disk.percent for disk in data)/len(data)

    @property
    def disk_bar(self):
        data,devices = self._all_disk()
        used = [round(disk.used/(1024**3),2) for disk in data]
        free = [round(disk.free/1024**3,2) for disk in data]
        name = [re.search("[A-Za-z]", name).group()+' 盘' for name in devices]
        return used, free, name

    @property
    def disk_io(self):
        if hasattr(self, "disk_io_info"):
            return self.disk_io_info
        self.disk_io_info = ps.disk_io_counters()

    def disk_all_info(self):
        for value in ps.disk_partitions():
            print(value.device)

    def _all_disk(self):
        devices = ([disk.device for disk in ps.disk_partitions() if disk.fstype])
        all_disks  = [(ps.disk_usage(device),device) for device in devices]
        result = sorted(all_disks, key=lambda x:x[0].total, reverse=True)
        all_disks = [data[0] for data in result]
        devices = [data[1] for data in result]
        return all_disks, devices

    def __str__(self):
        text = "磁盘大小:{}G 磁盘使用率:%{}"
        return text.format(round(self.get_total,2), round(self.disk_percent,2))

class NetInfo:
    def __init__(self):
        self.now_data = self.get_data()
    @property
    def _io_counter(self):
        return ps.net_io_counters()

    @property
    def net_data(self):
        # 网络接收发送
        rcvd = self._io_counter.bytes_recv
        send = self._io_counter.bytes_sent
        return rcvd, send

    @property
    def net_info(self):
        return ps.net_if_addrs()

    def _parse(self, data):
        s =data/1024 if data/1024 > 1 else None
        if s is None:
            return data, "B"
        d = s/1024 if s/1024 > 1 else None
        if d is None:
            return round(s, 2), "KB"
        return round(d, 2), "M"
    def get_data(self):
        rcve,send = self.net_data
        # reve = "%s %s" % self._parse(rcve)
        # send = "%s %s" % self._parse(send)
        return rcve, send

    @property
    def get_speed(self):
        now_reve, now_send = self.get_data()

        rcve_speed = (now_reve - self.now_data[0])/1024
        send_speed = (now_send - self.now_data[1])/1024
        rcve_speed = rcve_speed if 0 < rcve_speed < 100 else 0
        send_speed = send_speed if 0 < send_speed < 100 else 0
        self.now_data = (now_reve, now_send)
        # print(rcve_speed, send_speed)
        return round(rcve_speed,1), round(send_speed,1)
    @property
    def get_speed_datas(self):
        now_data = self.get_speed
        if hasattr(self, "recv_speed_datas") and hasattr(self, "send_speed_datas"):
            self.recv_speed_datas.append(now_data[0])
            if len(self.recv_speed_datas)>60:
                self.recv_speed_datas.pop(0)
            self.send_speed_datas.append(now_data[1])
            if len(self.send_speed_datas)>60:
                self.send_speed_datas.pop(0)
            return self.recv_speed_datas, self.send_speed_datas
        self.recv_speed_datas = [now_data[0]]
        self.send_speed_datas = [now_data[1]]
        return self.recv_speed_datas, self.send_speed_datas

    def __str__(self):
        rcve,send = self.net_data
        reve = "%s %s" % self._parse(rcve)
        send = "%s %s" % self._parse(send)
        return "接收:{} 发送:{}".format(reve, send)
class TheTime:
    def __init__(self):
        self.b_time = None

    @property
    def _now_time(self):
        return time.time()


    @property
    def now_time(self):
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time()))

    @property
    def _boot_time(self):
        if self.b_time is None:
            self.b_time = ps.boot_time()
        return self.b_time

    @property
    def boot_time(self):
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(self._boot_time))

    @property
    def used_time(self):
        # 使用时间
        data = self._now_time - self._boot_time
        if data>60:
            d = int(data/(3600*24))
            h = int((data%(3600*24))/3600)
            m = int((data%3600)/60)
            s = int(data%60)
            return "{} 天 {} 时 {} 分 {} 秒".format(d, h, m, s)
        else:
            return "{} 秒".format(int(data))
        # return self._now_time - self._boot_time

    def __str__(self):
        text = "开机时间:{} 当前时间:{}"
        return text.format(self.boot_time, self.now_time)