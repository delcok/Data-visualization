from django.shortcuts import render

# Create your views here.
import json
from random import randrange

from django.http import HttpResponse
from rest_framework.views import APIView
from pyecharts.commons.utils import JsCode
from pyecharts.charts import Bar,Gauge, Line, Pie
# from pyecharts.faker import  Faker
from pyecharts import options as opts
from .info import CpuData, Memory, IoInfo, NetInfo, TheTime
from django.conf import settings
from django.core.mail import send_mail
# Create your views here.
cpu = CpuData()
mermory = Memory()
disk = IoInfo()
net = NetInfo()
starttime = TheTime()

from_email = settings.DEFAULT_FROM_EMAIL
def response_as_json(data):
    json_str = json.dumps(data)
    response = HttpResponse(
        json_str,
        content_type="application/json",
    )
    response["Access-Control-Allow-Origin"] = "*"
    return response


def json_response(data, code=200):
    data = {
        "code": code,
        "msg": "success",
        "data": data,
    }
    return response_as_json(data)


def json_error(error_string="error", code=500, **kwargs):
    data = {
        "code": code,
        "msg": error_string,
        "data": {}
    }
    data.update(kwargs)
    return response_as_json(data)


JsonResponse = json_response
JsonError = json_error



def gauge_base(value, title) -> Gauge:
    if value > 80:
        # send_mail("cpu警告", "cpu占用:{} %".format(value), from_email, ['1174501146@qq.com'], fail_silently=False)
        pass
    c = (
        Gauge()
        .add("", [("使用率", value)])
        .set_global_opts(title_opts=opts.TitleOpts(title=title))
        .dump_options_with_quotes()
    )
    return c

class CpuView(APIView):
    def get(self, request, *args, **kwargs):
        return JsonResponse(json.loads(gauge_base(cpu.get_now_percent, title='Cpu使用率')))

class DiskView(APIView):
    def get(self, request, *args, **kwargs):
        # print(disk.disk_percent)
        return JsonResponse(json.loads(gauge_base(round(disk.disk_percent, 2), title='磁盘使用率')))

class MemoryView(APIView):
    def get(self, request, *args, **kwargs):
        return JsonResponse(json.loads(gauge_base(mermory.get_percent, title='内存使用率')))


def line_base(title) -> Line:
    recv,send = net.get_speed_datas
    # print(recv)
    # print(send)
    if not recv:
        recv = [0] * 60
        send = [0] * 60

    # elif len(recv) < 60:
    #     res = [0] * (60-len(recv))
    #     recv = res.extend(recv)
    #
    #     res = [0] * (60-len(recv))
    #     send = res.extend(res)
    line = (
        Line(init_opts={"animationOpts":opts.AnimationOpts(animation=False)})
        .add_xaxis([i for i in range(1, 61)])
        .add_yaxis("接收(Kb/s)", recv)
        .add_yaxis("发送(Kb/s)", send)
        .set_series_opts(
            areastyle_opts=opts.AreaStyleOpts(opacity=0.6),
            label_opts=opts.LabelOpts(is_show=False),
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(title=title),
            xaxis_opts=opts.AxisOpts(
                axistick_opts=opts.AxisTickOpts(is_align_with_label=True),
                is_scale=False,
                boundary_gap=False,
            ),

        )
        .dump_options_with_quotes()
    )
    return line

class NetView(APIView):
    def get(self, request, *args, **kwargs):
        return JsonResponse(json.loads(line_base(title="网络流量")))

cnt = 9
class NetUpdateView(APIView):
    def get(self, request, *args, **kwargs):
        global cnt
        return JsonResponse({"name": cnt, "value": net.get_speed[0]})
def pie_multiple_base() -> Pie:
    # fn = """
    # function(params) {
    #     if(params.name == '其他')
    #         return '\\n\\n\\n' + params.name + ' : ' + params.value + '%';
    #     return params.name + ' : ' + params.value + '%';
    # }
    # """

    def new_label_opts(data):
        return opts.LabelOpts(formatter="{total}:{tv}G\n\n{used}:{uv}G\n\n{free}:{fv}G".format(**data), position="center")

    c = (
        Pie()
        .add(
            "",
            [list(z) for z in zip(["已用", "内存可用"], mermory.get_used_free_data)],
            center=["20%", "30%"],
            radius=[60, 80],
            label_opts=new_label_opts(data={"total":"内存大小",'tv':mermory.get_total,
                                            "used":"已用内存", 'uv':mermory.get_used_free_data[0], "free":"可用",'fv':mermory.get_used_free_data[1]}),
        )
        .add(
            "",
            [list(z) for z in zip(["已用", "磁盘可用"], disk.disk_used_free_data)],
            center=["55%", "30%"],
            radius=[60, 80],
            label_opts=new_label_opts(data={"total":"磁盘大小",'tv':disk.get_total,
                                            "used":"已用磁盘", 'uv':disk.disk_used_free_data[0], "free":"可用",'fv':disk.disk_used_free_data[1]}),
        )
        .add(
            "",
            [list(z) for z in zip(["已用", "交换区可用"], mermory.get_swap_data)],
            center=["20%", "70%"],
            radius=[60, 80],
            label_opts=new_label_opts(data={"total":"交换内存大小",'tv':mermory.get_swap_total,
                    "used":"已用交换区", 'uv':mermory.get_swap_data[0], "free":"可用",'fv':mermory.get_swap_data[1]}),
        )
        .set_global_opts(
            title_opts=opts.TitleOpts(title="存储信息(G)"),
            legend_opts=opts.LegendOpts(
                type_="scroll", pos_top="60%", pos_left="48%", orient="vertical"
            ),
        )
        .dump_options_with_quotes()
    )
    return c
class InfoView(APIView):
    def get(self, request, *args, **kwargs):
        return JsonResponse(json.loads(pie_multiple_base()))


def bar_reversal_axis() -> Bar:
    used, free, name = disk.disk_bar
    c = (
        Bar()
        .add_xaxis(name)
        .add_yaxis("已使用", used,stack="stack1",
                   itemstyle_opts=opts.ItemStyleOpts(color={'type': 'linear','x': 0,'y': 0,'x2': 1,'y2': 1,'colorStops': [{
           'offset': 0, 'color': '#ffc09f'  #// 0% 处的颜色
       }, {
           'offset': 1, 'color': '#ffee93' #// 100% 处的颜色
       }],
       'globalCoord': False #// 缺省为 false
    }) )
        .add_yaxis("空闲", free,stack="stack1",
                  itemstyle_opts=opts.ItemStyleOpts(color={'type': 'linear','x': 0,'y': 0,'x2': 1,'y2': 1,'colorStops': [{
           'offset': 0, 'color': '#9dd3fa'  #// 0% 处的颜色
       }, {
           'offset': 1, 'color': 'red' #// 100% 处的颜色
       }],
       'globalCoord': False #// 缺省为 false
    }))
        .reversal_axis()
        .set_series_opts(label_opts=opts.LabelOpts(position="right"))
        .set_global_opts(title_opts=opts.TitleOpts(title="磁盘分区"))
        .dump_options_with_quotes()
    )
    return c
class DiskBarView(APIView):
    def get(self, request, *args, **kwargs):
        return JsonResponse(json.loads(bar_reversal_axis()))

class DataView(APIView):
    def get(self, request, *args, **kwargs):
        data = cpu.get_data
        data.update({"ti":starttime.used_time})
        return JsonResponse(data)

class IndexView(APIView):
    def get(self, request, *args, **kwargs):
        return HttpResponse(content=open("./templates/index.html", encoding='utf-8').read())
