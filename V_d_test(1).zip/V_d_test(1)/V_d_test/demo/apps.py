from django.apps import AppConfig


class DemoConfig(AppConfig):
    name = 'demo'
