# !/usr/bin/python
# -*-coding:utf-8_*_
# 作者      :tanxiaolong
# 创建时间  :2020/2/17 1:23 下午
# 文件      :urls.py
# IDE       :PyCharm
from django.urls import path
from . import views

urlpatterns = [
    path('/', views.IndexView.as_view(), name='index'),
    path('disk/', views.DiskView.as_view(), name='disk'),
    path("memory/", views.MemoryView.as_view(), name="memory"),
    path("cpu/", views.CpuView.as_view(), name="cpu"),
    path('net/',views.NetView.as_view(),name='net'),
    path('index/', views.IndexView.as_view(), name='index'),
    path('info/', views.InfoView.as_view(), name='info'),
    path("net_update", views.NetUpdateView.as_view(), name='netupdate'),
    path("disk_bar", views.DiskBarView.as_view(), name='diskbar'),
    path("data", views.DataView.as_view(), name='data')
]